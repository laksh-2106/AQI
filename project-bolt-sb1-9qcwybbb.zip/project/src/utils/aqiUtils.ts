import { AQI_LEVELS } from '../data/aqiLevels';
import { AQILevel } from '../types/aqi';

export const getAQILevel = (aqi: number): AQILevel => {
  return AQI_LEVELS.find(level => aqi >= level.min && aqi <= level.max) || AQI_LEVELS[0];
};

export const formatTimestamp = (timestamp: string): string => {
  return new Date(timestamp).toLocaleString('en-US', {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

export const getPollutantName = (pollutant: string): string => {
  const names: { [key: string]: string } = {
    pm25: 'PM2.5',
    pm10: 'PM10',
    o3: 'Ozone',
    no2: 'NO₂',
    so2: 'SO₂',
    co: 'CO'
  };
  return names[pollutant] || pollutant;
};

export const getPollutantUnit = (pollutant: string): string => {
  const units: { [key: string]: string } = {
    pm25: 'µg/m³',
    pm10: 'µg/m³',
    o3: 'µg/m³',
    no2: 'µg/m³',
    so2: 'µg/m³',
    co: 'mg/m³'
  };
  return units[pollutant] || 'µg/m³';
};