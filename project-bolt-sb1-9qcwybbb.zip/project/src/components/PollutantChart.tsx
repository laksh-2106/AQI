import React from 'react';
import { AQIData } from '../types/aqi';

interface PollutantChartProps {
  data: AQIData;
}

export const PollutantChart: React.FC<PollutantChartProps> = ({ data }) => {
  // Generate sample hourly data for the past 24 hours
  const generateHourlyData = () => {
    const hours = [];
    const now = new Date();
    
    for (let i = 23; i >= 0; i--) {
      const hour = new Date(now.getTime() - i * 60 * 60 * 1000);
      const variation = (Math.random() - 0.5) * 0.3; // ±15% variation
      hours.push({
        time: hour.getHours(),
        aqi: Math.max(10, Math.round(data.aqi * (1 + variation))),
        pm25: Math.max(1, Math.round(data.pollutants.pm25 * (1 + variation)))
      });
    }
    return hours;
  };

  const hourlyData = generateHourlyData();
  const maxAQI = Math.max(...hourlyData.map(h => h.aqi));
  
  return (
    <div className="bg-gray-50 rounded-xl p-6">
      <div className="flex items-end justify-between h-48 space-x-2">
        {hourlyData.map((hour, index) => {
          const height = (hour.aqi / maxAQI) * 100;
          return (
            <div key={index} className="flex flex-col items-center flex-1">
              <div 
                className="bg-blue-500 rounded-t-sm hover:bg-blue-600 transition-colors duration-200 w-full min-h-[4px]"
                style={{ height: `${height}%` }}
                title={`${hour.time}:00 - AQI: ${hour.aqi}`}
              />
              <span className="text-xs text-gray-500 mt-2">
                {hour.time}
              </span>
            </div>
          );
        })}
      </div>
      <div className="flex justify-between items-center mt-4 text-sm text-gray-600">
        <span>24 hours ago</span>
        <span>Current AQI: {data.aqi}</span>
        <span>Now</span>
      </div>
    </div>
  );
};