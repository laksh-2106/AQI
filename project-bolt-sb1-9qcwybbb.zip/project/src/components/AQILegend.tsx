import React from 'react';
import { Info } from 'lucide-react';
import { AQI_LEVELS } from '../data/aqiLevels';

export const AQILegend: React.FC = () => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
      <div className="flex items-center space-x-2 mb-6">
        <Info className="w-6 h-6 text-blue-600" />
        <h3 className="text-xl font-bold text-gray-900">AQI Scale</h3>
      </div>
      
      <div className="space-y-3">
        {AQI_LEVELS.map((level, index) => (
          <div key={index} className="flex items-center space-x-4">
            <div 
              className="w-16 px-2 py-1 rounded text-center text-xs font-medium"
              style={{ 
                backgroundColor: level.bgColor, 
                color: level.textColor 
              }}
            >
              {level.min}-{level.max}
            </div>
            <div className="flex-1">
              <div className="font-medium text-gray-900">{level.category}</div>
              <div className="text-sm text-gray-600">{level.description}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};