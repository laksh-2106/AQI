import React from 'react';
import { X, Activity, AlertTriangle, Info, TrendingUp } from 'lucide-react';
import { AQIData } from '../types/aqi';
import { getAQILevel, getPollutantName, getPollutantUnit } from '../utils/aqiUtils';
import { PollutantChart } from './PollutantChart';

interface DetailedViewProps {
  data: AQIData;
  onClose: () => void;
}

export const DetailedView: React.FC<DetailedViewProps> = ({ data, onClose }) => {
  const aqiLevel = getAQILevel(data.aqi);
  
  const pollutantEntries = Object.entries(data.pollutants);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white rounded-t-2xl border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{data.location}</h2>
            <p className="text-gray-600">Detailed Air Quality Report</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-8">
          {/* Current AQI Status */}
          <div className="text-center">
            <div 
              className="inline-flex items-center justify-center w-32 h-32 rounded-full mb-4"
              style={{ backgroundColor: aqiLevel.bgColor }}
            >
              <div className="text-center">
                <div className="text-4xl font-bold" style={{ color: aqiLevel.textColor }}>
                  {data.aqi}
                </div>
                <div className="text-sm" style={{ color: aqiLevel.textColor }}>
                  AQI
                </div>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">{aqiLevel.category}</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">{aqiLevel.description}</p>
          </div>

          {/* Pollutant Details */}
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <Activity className="w-6 h-6 text-blue-600" />
              <h3 className="text-xl font-bold text-gray-900">Pollutant Breakdown</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pollutantEntries.map(([key, value]) => (
                <div key={key} className="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors duration-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-600">
                      {getPollutantName(key)}
                    </span>
                    <span className="text-xs text-gray-500">
                      {getPollutantUnit(key)}
                    </span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Trend Chart */}
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <TrendingUp className="w-6 h-6 text-green-600" />
              <h3 className="text-xl font-bold text-gray-900">24-Hour Trend</h3>
            </div>
            <PollutantChart data={data} />
          </div>

          {/* Health Recommendations */}
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
              <h3 className="text-xl font-bold text-gray-900">Health Recommendations</h3>
            </div>
            <div className="space-y-3">
              {data.healthRecommendations.map((recommendation, index) => (
                <div key={index} className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg">
                  <Info className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{recommendation}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};