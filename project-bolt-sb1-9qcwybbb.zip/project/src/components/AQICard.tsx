import React from 'react';
import { MapPin, Clock, Thermometer } from 'lucide-react';
import { AQIData } from '../types/aqi';
import { getAQILevel, formatTimestamp } from '../utils/aqiUtils';

interface AQICardProps {
  data: AQIData;
  onClick: () => void;
}

export const AQICard: React.FC<AQICardProps> = ({ data, onClick }) => {
  const aqiLevel = getAQILevel(data.aqi);

  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1 border border-gray-200 overflow-hidden"
    >
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-2">
            <MapPin className="w-5 h-5 text-gray-500" />
            <h3 className="text-lg font-semibold text-gray-900">{data.location}</h3>
          </div>
          <div className="flex items-center space-x-1 text-sm text-gray-500">
            <Clock className="w-4 h-4" />
            <span>{formatTimestamp(data.timestamp)}</span>
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-4xl font-bold text-gray-900 mb-1">{data.aqi}</div>
            <div 
              className="inline-flex px-3 py-1 rounded-full text-sm font-medium"
              style={{ 
                backgroundColor: aqiLevel.bgColor, 
                color: aqiLevel.textColor 
              }}
            >
              {aqiLevel.category}
            </div>
          </div>
          <div className="text-right">
            <div 
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ backgroundColor: aqiLevel.bgColor }}
            >
              <Thermometer 
                className="w-8 h-8" 
                style={{ color: aqiLevel.color }} 
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="bg-gray-50 rounded-lg p-2">
            <div className="text-sm font-medium text-gray-900">{data.pollutants.pm25}</div>
            <div className="text-xs text-gray-500">PM2.5</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-2">
            <div className="text-sm font-medium text-gray-900">{data.pollutants.pm10}</div>
            <div className="text-xs text-gray-500">PM10</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-2">
            <div className="text-sm font-medium text-gray-900">{data.pollutants.o3}</div>
            <div className="text-xs text-gray-500">O₃</div>
          </div>
        </div>
      </div>
    </div>
  );
};