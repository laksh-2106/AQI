import { AQIData } from '../types/aqi';

export const SAMPLE_AQI_DATA: AQIData[] = [
  {
    location: 'New York, NY',
    coordinates: { lat: 40.7128, lng: -74.0060 },
    aqi: 67,
    category: 'Moderate',
    pollutants: {
      pm25: 18.5,
      pm10: 32.1,
      o3: 85.2,
      no2: 42.8,
      so2: 12.4,
      co: 1.2
    },
    timestamp: new Date().toISOString(),
    healthRecommendations: [
      'Sensitive individuals should limit outdoor activities',
      'Consider wearing a mask if you have respiratory conditions',
      'Keep windows closed during high pollution hours'
    ]
  },
  {
    location: 'Los Angeles, CA',
    coordinates: { lat: 34.0522, lng: -118.2437 },
    aqi: 89,
    category: 'Moderate',
    pollutants: {
      pm25: 25.3,
      pm10: 45.7,
      o3: 92.1,
      no2: 38.9,
      so2: 8.6,
      co: 1.8
    },
    timestamp: new Date().toISOString(),
    healthRecommendations: [
      'Air quality is acceptable for most people',
      'Sensitive groups should monitor symptoms',
      'Good time for outdoor activities'
    ]
  },
  {
    location: 'Beijing, China',
    coordinates: { lat: 39.9042, lng: 116.4074 },
    aqi: 156,
    category: 'Unhealthy',
    pollutants: {
      pm25: 85.4,
      pm10: 120.8,
      o3: 45.2,
      no2: 67.3,
      so2: 28.9,
      co: 2.4
    },
    timestamp: new Date().toISOString(),
    healthRecommendations: [
      'Avoid outdoor activities',
      'Wear an N95 mask when going outside',
      'Keep air purifiers running indoors',
      'Consider postponing exercise outdoors'
    ]
  },
  {
    location: 'London, UK',
    coordinates: { lat: 51.5074, lng: -0.1278 },
    aqi: 42,
    category: 'Good',
    pollutants: {
      pm25: 12.8,
      pm10: 21.4,
      o3: 65.7,
      no2: 31.2,
      so2: 6.8,
      co: 0.9
    },
    timestamp: new Date().toISOString(),
    healthRecommendations: [
      'Excellent conditions for outdoor activities',
      'No health concerns for any group',
      'Perfect time for jogging or cycling'
    ]
  }
];