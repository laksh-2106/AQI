import { AQILevel } from '../types/aqi';

export const AQI_LEVELS: AQILevel[] = [
  {
    min: 0,
    max: 50,
    category: 'Good',
    color: '#10b981',
    bgColor: '#d1fae5',
    textColor: '#065f46',
    description: 'Air quality is considered satisfactory, and air pollution poses little or no risk.'
  },
  {
    min: 51,
    max: 100,
    category: 'Moderate',
    color: '#f59e0b',
    bgColor: '#fef3c7',
    textColor: '#92400e',
    description: 'Air quality is acceptable; however, there may be a concern for some people who are unusually sensitive to air pollution.'
  },
  {
    min: 101,
    max: 150,
    category: 'Unhealthy for Sensitive Groups',
    color: '#f97316',
    bgColor: '#fed7aa',
    textColor: '#9a3412',
    description: 'Members of sensitive groups may experience health effects. The general public is not likely to be affected.'
  },
  {
    min: 151,
    max: 200,
    category: 'Unhealthy',
    color: '#ef4444',
    bgColor: '#fecaca',
    textColor: '#991b1b',
    description: 'Everyone may begin to experience health effects; members of sensitive groups may experience more serious health effects.'
  },
  {
    min: 201,
    max: 300,
    category: 'Very Unhealthy',
    color: '#8b5cf6',
    bgColor: '#ddd6fe',
    textColor: '#5b21b6',
    description: 'Health warnings of emergency conditions. The entire population is more likely to be affected.'
  },
  {
    min: 301,
    max: 500,
    category: 'Hazardous',
    color: '#7c2d12',
    bgColor: '#fef2f2',
    textColor: '#7c2d12',
    description: 'Health alert: everyone may experience more serious health effects.'
  }
];