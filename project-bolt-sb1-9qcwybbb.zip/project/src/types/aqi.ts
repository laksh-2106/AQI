export interface AQIData {
  location: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  aqi: number;
  category: string;
  pollutants: {
    pm25: number;
    pm10: number;
    o3: number;
    no2: number;
    so2: number;
    co: number;
  };
  timestamp: string;
  healthRecommendations: string[];
}

export interface AQILevel {
  min: number;
  max: number;
  category: string;
  color: string;
  bgColor: string;
  textColor: string;
  description: string;
}